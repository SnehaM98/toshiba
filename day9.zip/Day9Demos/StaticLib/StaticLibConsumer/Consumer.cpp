
#include "H:\training\StaticLib\Math.h"
#include<iostream>
using namespace std;
void main()
{
	cout<<add(1,2)<<endl;
}
