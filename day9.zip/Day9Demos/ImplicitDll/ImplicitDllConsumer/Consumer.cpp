
#include "H:\training\ImplicitDll\Math.h"
#include<iostream>
using namespace std;
void main()
{
	cout<<add(1,2)<<endl;
	cout<<add(1.1,2.2)<<endl;
	Student s;
	s.disp();
}
