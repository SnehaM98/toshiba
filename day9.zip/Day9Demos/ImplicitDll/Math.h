__declspec(dllexport)
int add(int,int);

__declspec(dllexport)
double add(double,double);


class __declspec(dllexport) Student
{
public:
	void disp();
};