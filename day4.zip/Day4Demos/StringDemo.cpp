#include<iostream>
#include<string>
using namespace std;

void main()
{
   string s1 = "Shobha";
   string s2 = "Bhardwaj";
   cout<<(s1+s2)<<endl;
}